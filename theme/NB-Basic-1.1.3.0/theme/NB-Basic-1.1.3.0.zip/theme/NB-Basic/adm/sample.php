<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$sample = array();

$sample[] = array("lwI6-jKlsO0", "Horizon Zero Dawn - Gameplay Trailer | PS4 Pro 4K");
$sample[] = array("uy6ne-fEsAw", "Dying Light 2 - 4K Gameplay Demo");
$sample[] = array("6LgVI2ze1dk", "Days Gone - Official Story Trailer");
$sample[] = array("u4-FCsiF5x4", "Horizon Zero Dawn - E3 2016 Trailer I Only On PS4");
$sample[] = array("btmN-bWwv0A", "The Last of Us Part II – E3 2018 Gameplay Reveal Trailer | PS4");
$sample[] = array("tCI396HyhbQ", "Death Stranding - Launch Trailer | PS4");

// 랜덤 섞기
shuffle($sample);