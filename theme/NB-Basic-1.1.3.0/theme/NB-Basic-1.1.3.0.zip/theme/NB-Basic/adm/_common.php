<?php
include_once('../../../common.php');
include_once(NA_PATH.'/lib/option.lib.php');