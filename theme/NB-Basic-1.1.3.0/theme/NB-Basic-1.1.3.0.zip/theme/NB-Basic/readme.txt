Theme Name: NB-Basic
Theme URI: http://amina.co.kr/nariya
Maker: 한별아빠, 아미나
Maker URI: http://amina.co.kr
Version: 1.1.3.0
Detail: 본 테마는 나리야 빌더가 설치되어 있어야 사용할 수 있습니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html