<?php
if(is_file('../../../common.php')) {
	include_once('../../../common.php');
} else {
	include_once('../../../../common.php');
}